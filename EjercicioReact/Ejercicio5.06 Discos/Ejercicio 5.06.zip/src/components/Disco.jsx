import React from 'react'
import "./Disco.css";

const Disco = () => {
  return (
    <div>Disco</div>
  )
}

export default Disco
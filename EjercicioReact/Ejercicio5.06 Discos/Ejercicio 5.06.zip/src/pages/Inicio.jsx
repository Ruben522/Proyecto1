import React from "react";
import "./Inicio.css";

// Componente de la página de inicio.
const Inicio = () => {
	return (
		<div className="inicio">
			<h2>Esta es la página de inicio</h2>
		</div>
	);
};

export default Inicio;

import React from 'react'

const Cargando = () => {
  return (
    <div>Cargando discos, espere por favor...</div>
  )
}

export default Cargando;
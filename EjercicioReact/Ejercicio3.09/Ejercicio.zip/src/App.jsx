import { useState } from 'react'
import Matricula from './components/Matricula'

function App() {
  return (
    <Matricula />
  )
}

export default App

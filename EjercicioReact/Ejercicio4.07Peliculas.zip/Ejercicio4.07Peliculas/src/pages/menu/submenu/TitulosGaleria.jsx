import React from 'react'

// Componente que mostrará los títulos de las películas en la galería.
const TitulosGaleria = () => {
    return (
        <div className='titulos-galeria'>
            <h2>Esta es la página de los títulos de la galería.</h2>
        </div>
    )
}

export default TitulosGaleria
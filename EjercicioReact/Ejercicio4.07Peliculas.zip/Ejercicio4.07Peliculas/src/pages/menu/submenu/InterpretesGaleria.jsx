import React from 'react'

// Componente que mostrará los intérpretes de las películas en la galería.
const InterpretesGaleria = () => {
    return (
        <div className='interpretes-galeria'>
            <h2>Esta es la página de intérpretes de la galería.</h2>
        </div>
    )
}

export default InterpretesGaleria
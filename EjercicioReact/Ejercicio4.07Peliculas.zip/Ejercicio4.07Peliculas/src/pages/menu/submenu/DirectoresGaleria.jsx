import React from 'react'

// Componente que mostrará los directores de las películas en la galería.
const DirectoresGaleria = () => {
    return (
        <div className='directores-galeria'>
            <h2>Esta es la página de directores de la galería.</h2>
        </div>
    )
}

export default DirectoresGaleria
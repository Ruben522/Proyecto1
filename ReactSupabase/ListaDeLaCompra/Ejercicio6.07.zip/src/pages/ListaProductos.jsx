import React from 'react'

// Páina que muestra la lista con sus productos.
// Contendrá acciones sobre el listado.
const ListaProductos = () => {
    return (
        <div className='lista-productos'>ListaProductos</div>
    )
}

export default ListaProductos